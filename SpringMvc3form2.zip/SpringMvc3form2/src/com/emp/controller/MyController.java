package com.emp.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.emp.bean.Employee;

@Controller
public class MyController {
		@RequestMapping(value="/home")
		public String getHomePage(Model m){
			Employee emp=new Employee();
			m.addAttribute("empKey", emp);
			return "register";
		}
		@RequestMapping(value="/store",method=RequestMethod.POST)
		public String StoreData(@ModelAttribute("empKey") @Valid Employee empl,Model m,BindingResult br){
		//	System.out.println(empl);
			//System.out.println(empl.getName());
			String target="error";
			if(br.hasErrors()){
				target="register";
			}
			return target;
		}

}

