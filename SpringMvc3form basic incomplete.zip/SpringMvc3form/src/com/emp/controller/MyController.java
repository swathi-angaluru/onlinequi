package com.emp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.emp.bean.Employee;

@Controller
public class MyController {

	@RequestMapping("/home")
	public String getHomePage(Model m){
		Employee employee=new Employee();
		m.addAttribute("emp", employee);//req scope
		return "welcome";
	}
	
	@RequestMapping(value="/getData")
	public String processD(){
		return "";
	}
	@RequestMapping(value="/getData",method=RequestMethod.POST)
	public String process(@RequestParam("userName") String name,@RequestParam("userCity") String city ){
		
		
		System.out.println("in process "+name+" "+city);
		String target="error";
		if("admin".equals(name)){
			target="success";
		}
		return target;
			
	}
}
