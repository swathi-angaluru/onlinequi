package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Trainee;
import com.cg.service.ITraineeService;


@Controller

public class MyController {

	@Autowired
	ITraineeService service;
	
	@RequestMapping("home")
	public String getlogin()
	{
		return "loginpage";
	}
	
	@RequestMapping("validate")
	public String validate(@RequestParam String uname, @RequestParam String pwd)
	{
		String page = "";
		if(uname.equalsIgnoreCase("admin") && pwd.equalsIgnoreCase("admin"))
		{
			System.out.println("in if ");
			page = "tms";
		}
		else
		{
			page="fail";
		}
		return page;
	}
	@RequestMapping("Addatrainee")
	public String addaTrainee(Model m)
	{	Trainee trainee = new Trainee();
		m.addAttribute("trainee", trainee);
		return "add";
	}
	
	@RequestMapping(value= "addtrainee",method=RequestMethod.POST)
	public String addTrainee(@ModelAttribute (value = "trainee") @Valid Trainee trainee,BindingResult br, Model m)
	{
		System.out.println("in addtrainee");
		System.out.println(br.hasErrors());
		String page="added";
		if(br.hasErrors())
		{
			System.out.println("in has errors");
			/*Trainee trainee = new Trainee();*/
			m.addAttribute("trainee", trainee);
			page="add";
		}
		else
		{
			System.out.println(trainee);
			Trainee tr = service.addTrainee(trainee);
			System.out.println(""+tr);
		}
			return page;
	}
	@RequestMapping("Deleteatrainee")
	public String delete()
	{
		return "delete";
	}
	@RequestMapping(value= "deletetr",method=RequestMethod.POST)
	public String deletetr(@RequestParam String Id,Model m)
	{
		String page="";
		boolean res;
		Trainee tr = service.findtr(Id);
		m.addAttribute("tr", tr);
		page = "delete";
		return page;
		
	}
}
