package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Trainee;

@Repository
@Transactional
public class DaoImpl implements IDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Trainee addTrainee(Trainee trainee) {
		System.out.println(entityManager);
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}

	@Override
	public boolean deleteTrainee(String id) {
		boolean result =false;
		Trainee tr = entityManager.find(Trainee.class, id);
		System.out.println(tr);
		if(tr!=null)
		{
		entityManager.remove(tr);
		result = true;
		}
		return result;
	}

	@Override
	public Trainee findtr(String id) {
		Trainee tr = entityManager.find(Trainee.class, id);
		return tr;
	}

}
