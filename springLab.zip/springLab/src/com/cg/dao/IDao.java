package com.cg.dao;

import com.cg.bean.Trainee;

public interface IDao {
	public Trainee addTrainee(Trainee trainee);
	public Trainee findtr(String id);
	public boolean deleteTrainee(String id);

}
