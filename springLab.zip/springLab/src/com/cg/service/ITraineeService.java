package com.cg.service;

import com.cg.bean.Trainee;

public interface ITraineeService {
	
	public Trainee addTrainee(Trainee trainee);

	public boolean deleteTrainee(String id);
	public Trainee findtr(String id);
}
