package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Trainee;
import com.cg.dao.IDao;
import com.cg.dao.DaoImpl;
@Service("service")
public class ITraineeServiceImpl implements ITraineeService {

	@Autowired
	IDao dao;
	@Override
	public Trainee addTrainee(Trainee trainee) {
		System.out.println("in service add trainee");
		return dao.addTrainee(trainee);
	}
	@Override
	public boolean deleteTrainee(String id) {
		return dao.deleteTrainee(id);
	}
	@Override
	public Trainee findtr(String id) {
		// TODO Auto-generated method stub
		return dao.findtr(id);
	}

}
