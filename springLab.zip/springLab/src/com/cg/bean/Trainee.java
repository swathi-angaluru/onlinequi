package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="trainee")
public class Trainee {


	@Id
	@NotBlank(message = "please enter trainee id")
	@Column(name="trainee_id")
	private String traineeid;
	
	@NotBlank(message="Plese enter name... This is a required field")
	@Column(name="trainee_Name")
	private String traineeName;
	
	@NotBlank( message = "please enter domain... ")
	@Column(name = "trainee_domain")
	private String traineeDomain;
	
	@NotBlank(message="Plese enter the location..")
	@Column(name = "trainee_location")
	private String traineeLocation;
	
	public String getTraineeid() {
		return traineeid;
	}
	public Trainee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setTraineeid(String traineeid) {
		this.traineeid = traineeid;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	@Override
	public String toString() {
		return "Trainee [traineeid=" + traineeid+
				", traineeName=" + traineeName + ", traineeDomain="
				+ traineeDomain + ", traineeLocation=" + traineeLocation + "]";
	}
	
	
}
