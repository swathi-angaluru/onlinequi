package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

	@RequestMapping("/home")
	public String getHome()
	{
		return "welcome";
	}
	
	@RequestMapping("/enterplan")
	public String enterplan()
	{
		return "enterplan";
	}
	@RequestMapping("viewall")
	public String viewall()
	{
		return "viewall";
	}
	@RequestMapping("viewbyplan")
	public String viewbyplan()
	{
		return "viewbyplan";
	}
}
