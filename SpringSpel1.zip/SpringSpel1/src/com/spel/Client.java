package com.spel;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Client {

	public static void main(String[] args) {
		ApplicationContext appContext = new ClassPathXmlApplicationContext("SpEL.xml");
		Company comp=(Company)appContext.getBean("company");
		
		System.out.println(comp.getcId());
		System.out.println(comp.getName());
		System.out.println(comp.getEmpl().geteId());
		System.out.println(comp.getEmpl().geteName());
		System.out.println(comp.getEmpList());
		comp.getEmpList().stream().forEach(System.out::println);
// solution for printing data inside the objects
		// map()
	}

}
