package com.spel;

public class ContractEmployee {
	private int cId;
	private String cName;
	
	public int getcId() {
		return cId;
	}
	public void setcId(int eId) {
		this.cId = eId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String eName) {
		this.cName = eName;
	}
	
}
