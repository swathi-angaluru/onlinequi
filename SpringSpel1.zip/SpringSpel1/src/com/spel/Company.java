package com.spel;

import java.util.ArrayList;


public class Company {

	private int cId;
	private String Name;
	private Employee empl;
	private ArrayList<Employee> empList;
	
	public ArrayList<Employee> getEmpList() {
		return empList;
	}
	public void setEmpList(ArrayList<Employee> empList) {
		this.empList = empList;
	}
	public int getcId() {
		return cId;
	}
	public void setcId(int cId) {
		this.cId = cId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Employee getEmpl() {
		return empl;
	}
	public void setEmpl(Employee empl) {
		this.empl = empl;
	}
	
	public Company() {
		// TODO Auto-generated constructor stub
	}
	
	
}
